﻿#pragma execution_character_set("utf-8")

#include "rulerbar.h"
#include "qpainter.h"
#include "qtimer.h"
#include "qdebug.h"
#include <cmath> // 添加cmath头文件用于fabs和fmod

RulerBar::RulerBar(QWidget *parent) : QWidget(parent)
{
    minValue = 0.0;
    maxValue = 5.0;  // 默认范围改为0~5
    value = 0.0;

    precision = 1;   // 默认精度改为1位小数
    longStep = 1.0;  // 长步进改为1.0
    shortStep = 0.5; // 短步进改为0.5
    space = 20;

    animation = false;
    animationStep = 0.1; // 动画步长减小

    bgColorStart = QColor(100, 100, 100);
    bgColorEnd = QColor(60, 60, 60);
    lineColor = QColor(255, 255, 255);

    barBgColor = QColor(250, 250, 250);
    barColor = QColor(100, 184, 255);

    reverse = false;
    currentValue = 0.0;
    timer = new QTimer(this);
    timer->setInterval(10);
    connect(timer, SIGNAL(timeout()), this, SLOT(updateValue()));

    QFont font;
    font.setFamily("Arial");
    font.setPixelSize(11);
    setFont(font);
}

RulerBar::~RulerBar()
{
    if (timer->isActive()) {
        timer->stop();
    }
}

void RulerBar::paintEvent(QPaintEvent *)
{
    // 绘制准备工作,启用反锯齿
    QPainter painter(this);
    painter.setRenderHints(QPainter::Antialiasing | QPainter::TextAntialiasing);

    // 绘制背景
    drawBg(&painter);
    // 绘制标尺
    drawRuler(&painter);
    // 绘制柱状背景
    drawBarBg(&painter);
    // 绘制柱状
    drawBar(&painter);
}

void RulerBar::drawBg(QPainter *painter)
{
    painter->save();
    painter->setPen(Qt::NoPen);
    QLinearGradient bgGradient(QPointF(0, 0), QPointF(0, height()));
    bgGradient.setColorAt(0.0, bgColorStart);
    bgGradient.setColorAt(1.0, bgColorEnd);
    painter->setBrush(bgGradient);
    painter->drawRect(rect());
    painter->restore();
}

void RulerBar::drawRuler(QPainter *painter)
{
    painter->save();
    painter->setPen(lineColor);

    // 绘制纵向标尺线 20的长度为刻度尺文字的宽度
    double initX = space + 20;
    double initY = space;
    QPointF topPot(initX, initY);
    QPointF bottomPot(initX, height() - space);
    painter->drawLine(topPot, bottomPot);

    // 绘制纵向标尺刻度
    double length = height() - 2 * space;
    // 计算每一格移动多少
    double increment = length / (maxValue - minValue);
    // 长线条短线条长度
    int longLineLen = 10;
    int shortLineLen = 4;  // 固定短刻度长度

    const double tolerance = 1e-6; // 浮点比较容差

    // 使用整数计数避免浮点累计误差
    int stepCount = static_cast<int>((maxValue - minValue) / shortStep + 1);

    for (int i = 0; i <= stepCount; i++) {
        double current = maxValue - i * shortStep;

        // 确保当前值在范围内
        if (current < minValue - tolerance) continue;

        // 计算当前刻度对应的y坐标
        double currentY = space + (maxValue - current) * increment;

        // 判断是否为长刻度（整数或边界值）
        bool isLongStep = false;
        if (fabs(fmod(current + tolerance, longStep)) < tolerance * 2) {
            isLongStep = true;
        }
        if (fabs(current - minValue) < tolerance || fabs(current - maxValue) < tolerance) {
            isLongStep = true;
        }

        if (isLongStep) {
            QPointF leftPot(initX + longLineLen, currentY);
            QPointF rightPot(initX, currentY);
            painter->drawLine(leftPot, rightPot);

            // 格式化数值显示
            QString text;
            if (fabs(current - round(current)) < tolerance) {
                text = QString::number(round(current), 'f', 0); // 整数显示
            } else {
                text = QString::number(current, 'f', precision); // 小数显示
            }

#if (QT_VERSION >= QT_VERSION_CHECK(5,11,0))
            double fontWidth = painter->fontMetrics().horizontalAdvance(text);
#else
            double fontWidth = painter->fontMetrics().width(text);
#endif
            double fontHeight = painter->fontMetrics().height();
            QPointF textPot(initX - fontWidth - 5, currentY + fontHeight / 3);
            painter->drawText(textPot, text);
        } else {
            // 短刻度
            QPointF leftPot(initX + shortLineLen, currentY);
            QPointF rightPot(initX, currentY);
            painter->drawLine(leftPot, rightPot);
        }
    }

    painter->restore();
}

// ... 保留原有代码直到 setShortStep 函数 ...

void RulerBar::setShortStep(double shortStep)
{
    // 确保步长不小于0.1
    double validStep = qMax(0.1, qAbs(shortStep));

    if (fabs(this->shortStep - validStep) > 1e-6) {
        this->shortStep = validStep;
        this->update();
    }
}

void RulerBar::drawBarBg(QPainter *painter)
{
    painter->save();
    painter->setPen(Qt::NoPen);

    // 20的长度为刻度尺文字的宽度 15为刻度尺到柱状图的宽度
    double initX = space + 20 + 15;
    QPointF topLeftPot(initX, space);
    QPointF bottomRightPot(width() - space, height() - space);
    barRect = QRectF(topLeftPot, bottomRightPot);

    painter->setBrush(barBgColor);
    painter->drawRect(barRect);
    painter->restore();
}

void RulerBar::drawBar(QPainter *painter)
{
    painter->save();
    painter->setPen(Qt::NoPen);

    double barHeight = barRect.height();
    double increment = barHeight / (maxValue - minValue);
    double initY = barRect.bottom() - (currentValue - minValue) * increment;

    QPointF topLeftPot(barRect.left(), initY);
    QPointF bottomRightPot(barRect.right(), barRect.bottom());
    QRectF currentRect(topLeftPot, bottomRightPot);

    painter->setBrush(barColor);
    painter->drawRect(currentRect);
    painter->restore();
}

double RulerBar::getMinValue() const
{
    return this->minValue;
}

double RulerBar::getMaxValue() const
{
    return this->maxValue;
}

double RulerBar::getValue() const
{
    return this->value;
}

int RulerBar::getPrecision() const
{
    return this->precision;
}

double RulerBar::getLongStep() const  // 改为double
{
    return this->longStep;
}

double RulerBar::getShortStep() const  // 改为double
{
    return this->shortStep;
}

int RulerBar::getSpace() const
{
    return this->space;
}

bool RulerBar::getAnimation() const
{
    return this->animation;
}

double RulerBar::getAnimationStep() const
{
    return this->animationStep;
}

QColor RulerBar::getBgColorStart() const
{
    return this->bgColorStart;
}

QColor RulerBar::getBgColorEnd() const
{
    return this->bgColorEnd;
}

QColor RulerBar::getLineColor() const
{
    return this->lineColor;
}

QColor RulerBar::getBarBgColor() const
{
    return this->barBgColor;
}

QColor RulerBar::getBarColor() const
{
    return this->barColor;
}

QSize RulerBar::sizeHint() const
{
    return QSize(100, 350);
}

QSize RulerBar::minimumSizeHint() const
{
    return QSize(20, 50);
}

void RulerBar::setRange(double minValue, double maxValue)
{
    // 如果最小值大于或者等于最大值则不设置
    if (minValue >= maxValue) {
        return;
    }

    this->minValue = minValue;
    this->maxValue = maxValue;

    // 如果目标值不在范围值内,则重新设置目标值
    // 值小于最小值则取最小值,大于最大值则取最大值
    if (value < minValue) {
        setValue(minValue);
    } else if (value > maxValue) {
        setValue(maxValue);
    }

    this->update();
}

void RulerBar::setRange(int minValue, int maxValue)
{
    setRange((double)minValue, (double)maxValue);
}

void RulerBar::setMinValue(double minValue)
{
    setRange(minValue, maxValue);
}

void RulerBar::setMaxValue(double maxValue)
{
    setRange(minValue, maxValue);
}

void RulerBar::setValue(double value)
{
    // 值和当前值一致则无需处理
    if (value == this->value) {
        return;
    }

    // 值小于最小值则取最小值,大于最大值则取最大值
    if (value < minValue) {
        value = minValue;
    } else if (value > maxValue) {
        value = maxValue;
    }

    if (value > this->value) {
        reverse = false;
    } else if (value < this->value) {
        reverse = true;
    }

    this->value = value;
    emit valueChanged(value);

    if (!animation) {
        currentValue = this->value;
        this->update();
    } else {
        timer->start();
    }
}

void RulerBar::setValue(int value)
{
    setValue((double)value);
}

void RulerBar::setPrecision(int precision)
{
    // 最大精确度为 3
    if (precision <= 3 && this->precision != precision) {
        this->precision = precision;
        this->update();
    }
}

void RulerBar::setLongStep(double longStep)  // 参数改为double
{
    if (fabs(this->longStep - longStep) > 1e-6) {
        this->longStep = longStep;
        this->update();
    }
}

void RulerBar::setSpace(int space)
{
    if (this->space != space) {
        this->space = space;
        this->update();
    }
}

void RulerBar::setAnimation(bool animation)
{
    if (this->animation != animation) {
        this->animation = animation;
        this->update();
    }
}

void RulerBar::setAnimationStep(double animationStep)
{
    if (fabs(this->animationStep - animationStep) > 1e-6) {
        this->animationStep = animationStep;
        this->update();
    }
}

void RulerBar::setBgColorStart(const QColor &bgColorStart)
{
    if (this->bgColorStart != bgColorStart) {
        this->bgColorStart = bgColorStart;
        this->update();
    }
}

void RulerBar::setBgColorEnd(const QColor &bgColorEnd)
{
    if (this->bgColorEnd != bgColorEnd) {
        this->bgColorEnd = bgColorEnd;
        this->update();
    }
}

void RulerBar::setLineColor(const QColor &lineColor)
{
    if (this->lineColor != lineColor) {
        this->lineColor = lineColor;
        this->update();
    }
}

void RulerBar::setBarBgColor(const QColor &barBgColor)
{
    if (this->barBgColor != barBgColor) {
        this->barBgColor = barBgColor;
        this->update();
    }
}

void RulerBar::setBarColor(const QColor &barColor)
{
    if (this->barColor != barColor) {
        this->barColor = barColor;
        this->update();
    }
}

void RulerBar::updateValue()
{
    if (!reverse) {
        if (currentValue >= value) {
            currentValue = value;
            timer->stop();
        } else {
            currentValue += animationStep;
        }
    } else {
        if (currentValue <= value) {
            currentValue = value;
            timer->stop();
        } else {
            currentValue -= animationStep;
        }
    }

    this->update();
}
